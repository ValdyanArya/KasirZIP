<?php
$conn = new mysqli("localhost", "root", "", "webkasir");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET["idmenu"])) {
    $idmenu = $_GET["idmenu"];
    $check_sql = "SELECT * FROM menu WHERE idmenu = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("i", $idmenu);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $delete_sql = "DELETE FROM menu WHERE idmenu = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("i", $idmenu);

        if ($stmt->execute()) {
            echo "<script>
                    alert('Menu berhasil dihapus!');
                    window.location = 'waiter_menu.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Gagal menghapus menu!');
                    window.location = 'waiter_menu.php';
                  </script>";
        }
    } else {
        echo "<script>
                alert('Menu tidak ditemukan!');
                window.location = 'waiter_menu.php';
              </script>";
    }
    $stmt->close();
} else {
    echo "<script>
            alert('ID menu tidak valid!');
            window.location = 'waiter_menu.php';
          </script>";
}

$conn->close();
?>