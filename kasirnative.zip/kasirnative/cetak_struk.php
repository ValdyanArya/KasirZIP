<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webkasir";

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id_transaksi = $_GET['id'];

    $query = "SELECT t.*, p.nama_pelanggan 
              FROM transaksi t
              JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
              WHERE t.id_transaksi = $id_transaksi";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $transaksi = $result->fetch_assoc();

        $query_detail = "SELECT m.nama, m.harga, p.jumlah, (m.harga * p.jumlah) as subtotal
                        FROM pesanan p
                        JOIN menu m ON p.idmenu = m.idmenu
                        WHERE p.id_pelanggan = {$transaksi['id_pelanggan']}";
        $detail_result = $conn->query($query_detail);
        ?>

<!DOCTYPE html>
<html>
<head>
    <title>Struk Transaksi #<?= $id_transaksi ?></title>
    <style>
    body { font-family: Arial, sans-serif; }
    .header { text-align: center; margin-bottom: 20px; }
    .title { font-size: 24px; font-weight: bold; }
    .info { margin-bottom: 15px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
    .total { font-weight: bold; text-align: right; }
    .footer { text-align: center; margin-top: 30px; font-style: italic; }
    .print-btn { margin: 20px auto; display: block; padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }

    @media print {
        .print-btn {
            display: none;
        }
    }
</style>

</head>
<body>

    <button class="print-btn" onclick="window.print()">Cetak Struk</button>

    <div class="header">
        <div class="title">Bass Restoran</div>
    </div>

    <div class="info">
        <div><strong>No. Transaksi:</strong> #<?= $id_transaksi ?></div>
        <div><strong>Tanggal:</strong> <?= $transaksi['tanggal_transaksi'] ?></div>
        <div><strong>Pelanggan:</strong> <?= $transaksi['nama_pelanggan'] ?></div>
    </div>

    <table>
        <tr>
            <th>Menu</th>
            <th>Harga</th>
            <th>Qty</th>
            <th>Subtotal</th>
        </tr>
        <?php while($detail = $detail_result->fetch_assoc()): ?>
        <tr>
            <td><?= $detail['nama'] ?></td>
            <td>Rp <?= number_format($detail['harga'], 0, ',', '.') ?></td>
            <td><?= $detail['jumlah'] ?></td>
            <td>Rp <?= number_format($detail['subtotal'], 0, ',', '.') ?></td>
        </tr>
        <?php endwhile; ?>
        <tr class="total">
            <td colspan="3">Total Awal</td>
            <td>Rp <?= number_format($transaksi['total'], 0, ',', '.') ?></td>
        </tr>
        <tr class="total">
            <td colspan="3">Diskon (<?= $transaksi['diskon'] ?>%)</td>
            <td>Rp <?= number_format($transaksi['total'] * $transaksi['diskon'] / 100, 0, ',', '.') ?></td>
        </tr>
        <tr class="total">
            <td colspan="3">Total Akhir</td>
            <td>Rp <?= number_format($transaksi['total_akhir'], 0, ',', '.') ?></td>
        </tr>
        <tr class="total">
            <td colspan="3">Bayar</td>
            <td>Rp <?= number_format($transaksi['bayar'], 0, ',', '.') ?></td>
        </tr>
        <tr class="total">
            <td colspan="3">Kembalian</td>
            <td>Rp <?= number_format($transaksi['kembalian'], 0, ',', '.') ?></td>
        </tr>
    </table>

    <div class="footer">
        Terima kasih telah berkunjung<br>
        Silahkan datang kembali
    </div>
</body>
</html>

<?php
    } else {
        echo "Transaksi tidak ditemukan";
    }
} else {
    echo "ID Transaksi tidak valid";
}
?>
