<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "webkasir");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_menus = $_POST["nama_menu"]; // array
    $jumlahs = $_POST["jumlah"];     // array
    $id_pelanggan = $_POST["nama_pelanggan"];
    $id_meja = $_POST["nomor_meja"];
    $username = trim($_POST["username"]);
    $tanggal_pesanan = $_POST["tanggal_pesanan"];


    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";

    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    $id_user = $user['id'] ?? null;

    if ($id_user && count($id_menus) == count($jumlahs)) {
        $conn->begin_transaction();
        $success = true;

        $stmt_insert = $conn->prepare("INSERT INTO pesanan (idmenu, id_pelanggan, jumlah, nomor, id_user, tanggal_pesanan) VALUES (?, ?, ?, ?, ?, ?)");


        for ($i = 0; $i < count($id_menus); $i++) {
            $id_menu = $id_menus[$i];
            $jumlah = $jumlahs[$i];

            $stmt_insert->bind_param("iiiiss", $id_menu, $id_pelanggan, $jumlah, $id_meja, $id_user, $tanggal_pesanan);
            if (!$stmt_insert->execute()) {
                $success = false;
                break;
            }
        }
        $stmt_insert->close();

        if ($success) {
            $stmt_update_meja = $conn->prepare("UPDATE meja SET status = 'Tidak Tersedia' WHERE Nomor = ?");
            $stmt_update_meja->bind_param("i", $id_meja);
            $stmt_update_meja->execute();
            $stmt_update_meja->close();

            $conn->commit();
            echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: 'Pesanan berhasil ditambahkan.'
                }).then(() => {
                    window.location.href = 'waiter_pesanan.php';
                });
            </script>";
        } else {
            $conn->rollback();
            echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: 'Gagal menambahkan semua pesanan.'
                }).then(() => {
                    window.history.back();
                });
            </script>";
        }
    } else {
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: 'User tidak ditemukan atau input tidak valid.'
            }).then(() => {
                window.history.back();
            });
        </script>";
    }
}
$conn->close();
?>

<?php
// Aktifkan debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "webkasir");

// Periksa koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil daftar menu
$menu_query = $conn->query("SELECT idmenu, nama FROM menu");
$menus = $menu_query->fetch_all(MYSQLI_ASSOC);

// Ambil daftar pelanggan
$pelanggan_query = $conn->query("SELECT id_pelanggan, nama_pelanggan FROM pelanggan");
$pelanggans = $pelanggan_query->fetch_all(MYSQLI_ASSOC);

// Ambil daftar nomor meja
$meja_query = $conn->query("SELECT Nomor FROM meja where status = 'Tersedia'");
$mejas = $meja_query->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pesanan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #2e59d9;
            --text-color: #5a5c69;
            --light-gray: #f8f9fa;
            --dark-gray: #d1d3e2;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--secondary-color);
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 100%;
            max-width: 700px;
        }

        .card-header {
            background-color: var(--primary-color);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }

        .card-body {
            padding: 2rem;
        }

        .form-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: var(--text-color);
        }

        .form-control, .form-select {
            border-radius: 8px;
            padding: 10px 15px;
            border: 1px solid var(--dark-gray);
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
        }

        .btn-primary {
            background-color: var(--primary-color);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .btn-primary:hover {
            background-color: var(--accent-color);
            transform: translateY(-2px);
        }

        .btn-secondary {
            background-color: #6c757d;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .btn-success {
            background-color: #1cc88a;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-success:hover {
            background-color: #17a673;
            transform: translateY(-2px);
        }

        .btn-danger {
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-danger:hover {
            transform: translateY(-2px);
        }

        .menu-group {
            background-color: var(--light-gray);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }

        .menu-group:hover {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .add-btn-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .input-group {
            margin-bottom: 10px;
        }

        @media (max-width: 768px) {
            .card-body {
                padding: 1.5rem;
            }
            
            .row {
                flex-direction: column;
            }
            
            .col-md-6, .col-md-4, .col-md-2 {
                width: 100%;
                margin-bottom: 10px;
            }
            
            .remove-menu {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <div class="card">
        <div class="card-header text-center">
            <h3 class="m-0"><i class="fas fa-utensils me-2"></i>Tambah Pesanan Baru</h3>
        </div>
        <div class="card-body">
            <form action="proses_pesanan.php" method="POST" id="orderForm">
                <div id="menuContainer">
                    <div class="menu-group">
                        <div class="row align-items-center">
                            <div class="col-md-6 mb-2">
                                <label class="form-label">Menu</label>
                                <select name="nama_menu[]" class="form-select" required>
                                    <option value="">Pilih Menu</option>
                                    <?php foreach ($menus as $menu): ?>
                                        <option value="<?= $menu['idmenu'] ?>"><?= $menu['nama'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label class="form-label">Jumlah</label>
                                <input type="number" class="form-control" name="jumlah[]" placeholder="0" min="1" required>
                            </div>
                            <div class="col-md-2 d-flex align-items-end mb-2">
                                <button type="button" class="btn btn-danger remove-menu w-80">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="add-btn-container">
                    <button type="button" class="btn btn-success" id="addMenuBtn">
                        <i class="fas fa-plus-circle me-2"></i>Tambah Menu
                    </button>
                </div>

                <div class="mb-4">
                    <label for="nama_pelanggan" class="form-label">Nama Pelanggan</label>
                    <select class="form-select" id="nama_pelanggan" name="nama_pelanggan" required>
                        <option value="">Pilih Pelanggan</option>
                        <?php foreach ($pelanggans as $pelanggan): ?>
                            <option value="<?= htmlspecialchars($pelanggan['id_pelanggan']); ?>">
                                <?= htmlspecialchars($pelanggan['nama_pelanggan']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="nomor_meja" class="form-label">Nomor Meja</label>
                    <select class="form-select" id="nomor_meja" name="nomor_meja" required>
                        <option value="">Pilih Meja</option>
                        <?php foreach ($mejas as $meja): ?>
                            <option value="<?= htmlspecialchars($meja['Nomor']); ?>">
                                Meja <?= htmlspecialchars($meja['Nomor']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="username" class="form-label">Username Pelayan</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan username" required>
                </div>

                <input type="date" class="form-control" name="tanggal_pesanan" required>


                <div class="action-buttons">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-2"></i>Kirim Pesanan
                    </button>
                    <a href="waiter_pesanan.php" class="btn btn-secondary">
                        <i class="fas fa-times me-2"></i>Batal
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Add new menu item
            document.getElementById('addMenuBtn').addEventListener('click', function() {
                const menuContainer = document.getElementById('menuContainer');
                const newMenuGroup = document.createElement('div');
                newMenuGroup.className = 'menu-group';
                newMenuGroup.innerHTML = `
                    <div class="row align-items-center">
                        <div class="col-md-6 mb-2">
                            <label class="form-label">Menu</label>
                            <select name="nama_menu[]" class="form-select" required>
                                <option value="">Pilih Menu</option>
                                <?php foreach ($menus as $menu): ?>
                                    <option value="<?= $menu['idmenu'] ?>"><?= $menu['nama'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-2">
                            <label class="form-label">Jumlah</label>
                            <input type="number" class="form-control" name="jumlah[]" placeholder="0" min="1" required>
                        </div>
                        <div class="col-md-2 d-flex align-items-end mb-2">
                            <button type="button" class="btn btn-danger remove-menu w-100">
                                <i class="fas fa-trash-alt"></i> Hapus
                            </button>
                        </div>
                    </div>
                `;
                menuContainer.appendChild(newMenuGroup);
                
                // Scroll to the new item
                newMenuGroup.scrollIntoView({ behavior: 'smooth' });
            });

            // Remove menu item
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('remove-menu')) {
                    const menuGroup = e.target.closest('.menu-group');
                    if (document.querySelectorAll('.menu-group').length > 1) {
                        menuGroup.remove();
                    } else {
                        // Reset the first menu group instead of removing it
                        const select = menuGroup.querySelector('select');
                        const input = menuGroup.querySelector('input');
                        select.selectedIndex = 0;
                        input.value = '';
                    }
                }
            });

            // Form validation
            document.getElementById("orderForm").addEventListener("submit", function(e) {
                const selects = document.querySelectorAll("select[name='nama_menu[]']");
                const jumlahs = document.querySelectorAll("input[name='jumlah[]']");
                let valid = true;

                selects.forEach((select, index) => {
                    if (select.value === "" || jumlahs[index].value === "" || parseInt(jumlahs[index].value) < 1) {
                        valid = false;
                        select.classList.add('is-invalid');
                        jumlahs[index].classList.add('is-invalid');
                    } else {
                        select.classList.remove('is-invalid');
                        jumlahs[index].classList.remove('is-invalid');
                    }
                });

                if (!valid) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'warning',
                        title: 'Oops!',
                        text: 'Harap lengkapi semua data menu dengan jumlah yang valid.',
                        confirmButtonColor: '#4e73df'
                    });
                }
            });
        });
    </script>
</body>
</html>