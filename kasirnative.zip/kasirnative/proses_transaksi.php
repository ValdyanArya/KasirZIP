<?php
// Tampilkan error saat pengembangan
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id_pelanggan'], $_POST['bayar'], $_POST['tanggal'], $_POST['kembalian'], $_POST['total_akhir'], $_POST['diskon'])) {
    $id_pelanggan = (int) $_POST['id_pelanggan'];
    $bayar = (int) $_POST['bayar'];
    $tanggal = $conn->real_escape_string($_POST['tanggal']);
    $kembalian = (int) $_POST['kembalian'];
    $total_akhir = (int) $_POST['total_akhir'];
    $diskon = (int) $_POST['diskon'];

    $query = "SELECT m.harga, p.jumlah, p.Nomor 
              FROM pesanan p
              JOIN menu m ON p.idmenu = m.idmenu
              WHERE p.id_pelanggan = $id_pelanggan";
    $result = $conn->query($query);

    $total_awal = 0;
    $no_meja = null;

    if ($result && $result->num_rows > 0) {
        while ($data = $result->fetch_assoc()) {
            $total_awal += $data['harga'] * $data['jumlah'];
            $no_meja = $data['Nomor'];
        }
    } else {
        showAlert('Error!', 'Pesanan tidak ditemukan untuk pelanggan ini!', 'error', true);
        exit;
    }

    // Validasi perhitungan diskon
    $calculated_total = $total_awal - ($total_awal * $diskon / 100);
    if (abs($calculated_total - $total_akhir) > 100) { // Toleransi perbedaan kecil karena pembulatan
        showAlert('Error!', 'Perhitungan diskon tidak valid!', 'error', true);
        exit;
    }

    if ($bayar < $total_akhir) {
        showAlert('Error!', 'Uang bayar kurang!', 'error', true);
        exit;
    }

    // Mulai transaksi database
    $conn->begin_transaction();

    try {
        $insert = "INSERT INTO transaksi (id_pelanggan, total, bayar, kembalian, tanggal_transaksi, diskon, total_akhir)
                   VALUES ($id_pelanggan, $total_awal, $bayar, $kembalian, '$tanggal', $diskon, $total_akhir)";

        if ($conn->query($insert)) {
            if ($no_meja) {
                $update_meja = "UPDATE meja SET status = 'tersedia' WHERE Nomor = '$no_meja'";
                if (!$conn->query($update_meja)) {
                    throw new Exception("Gagal update status meja");
                }
            }

            $conn->commit();
            showAlert('Sukses!', "Transaksi berhasil dan meja $no_meja telah tersedia! Diskon: $diskon%", 'success', false, 'kasir_transaksi.php');
            exit;
        } else {
            throw new Exception("Gagal menyimpan transaksi");
        }
    } catch (Exception $e) {
        $conn->rollback();
        showAlert('Error!', $e->getMessage(), 'error', true);
        exit;
    }
} else {
    showAlert('Error!', 'Data tidak lengkap!', 'error', true);
    exit;
}

/**
 * Menampilkan SweetAlert dalam HTML yang valid
 */
function showAlert($title, $text, $icon, $back = false, $redirect = null)
{
    echo "<!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Notifikasi</title>
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
    </head>
    <body>
    <script>
        Swal.fire({
            title: '".addslashes($title)."',
            text: '".addslashes($text)."',
            icon: '$icon',
            confirmButtonText: 'OK'
        }).then(() => {";

    if ($back) {
        echo "window.history.back();";
    } elseif ($redirect) {
        echo "window.location.href = '$redirect';";
    }

    echo "});
    </script>
    </body>
    </html>";
}
?>